<?php get_header(); ?>

	<div class="container">	
		<div class="section padded_block">
				<div class="warning_msg closable"><?php _e('The page you are trying to access does not exist!', 'Fortuna');?></div>
		</div>
	</div>	

<?php get_footer(); ?>